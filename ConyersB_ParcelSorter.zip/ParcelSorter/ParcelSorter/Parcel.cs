﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParcelSorter
{
    class Parcel : IComparable<Parcel>
    {
        private static Random rando = new Random();
        private float ParcelHeight { get; }
        private float ParcelWidth { get; }
        private float parcelDepth { get; }
        private readonly int parcelID;
        private static int idTracker = 0; 
        public float WeightPerCubicInch { get; set; }
        private float ParcelWeight { set; get; }

        public Parcel(float weight, float height, float width, float depth)
        {
            this.ParcelHeight = height;
            this.ParcelWidth = width;
            this.parcelDepth = depth;
            this.parcelID = idTracker;
            idTracker++;
            ParcelWeight = weight;
            WeightPerCubicInch = (weight)/ (width * height * depth);



        }

        public int CompareTo(Parcel other)
        {
            if(this.WeightPerCubicInch > other.WeightPerCubicInch)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        public override string ToString()
        {
            StringBuilder parcelSB = new StringBuilder();
            parcelSB.Append("=== | Parcel ID: " + this.parcelID + "\n");
            parcelSB.Append("Height: " + this.ParcelHeight.ToString("F2") + " in.\n");
            parcelSB.Append("Width: " + this.ParcelWeight.ToString("F2") + " in.\n");
            parcelSB.Append("Depth: " + this.parcelDepth.ToString("F2") + " in.\n");
            parcelSB.Append("Weight: " + this.ParcelWeight.ToString("F2") + " lbs.\n");
            parcelSB.Append("Pounds per Cubic In. :" + this.WeightPerCubicInch.ToString("F2") + " lbs.\n");
            return parcelSB.ToString();
        }
    }
}
